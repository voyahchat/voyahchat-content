#!/system/bin/sh
UPAN='busybox mount | grep "/mnt/media_rw" | busybox awk '{print $3}' | tail -n 1'

setenforce 0

busybox telnetd -l sh

sleep 2

am start ru.kachalin.voyahtweaks/.android.activity.main.MainActivity

